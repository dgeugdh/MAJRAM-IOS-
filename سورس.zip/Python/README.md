# 🎵 DROX MUSIC BOT

بوت تليجرام لتشغيل الموسيقى في المجموعات والقنوات

## 📋 المتطلبات

تم تنصيب جميع المتطلبات تلقائياً ✅

## 🔑 الإعداد

### 1. الحصول على بيانات API من تليجرام
- سجل دخول على https://my.telegram.org
- اذهب إلى API Development Tools
- احصل على:
  - `API_ID`
  - `API_HASH`

### 2. إنشاء البوت من BotFather
- تحدث مع [@BotFather](https://t.me/BotFather) على تليجرام
- أنشئ بوت جديد واحصل على `BOT_TOKEN`

### 3. إنشاء SESSION جديد (مهم جداً!)
قم بتشغيل:
```bash
python generate_session.py
```

سيطلب منك:
- `API_ID`
- `API_HASH`
- رقم هاتفك
- كود التحقق

بعدها سيعطيك SESSION جديد، انسخه.

### 4. تحديث ملف .env
افتح ملف `.env` وضع البيانات:
```env
API_ID=ضع_هنا_API_ID
API_HASH=ضع_هنا_API_HASH
BOT_TOKEN=ضع_هنا_BOT_TOKEN
OWNER_ID=ضع_هنا_ايدي_تليجرام_الخاص_بك
SESSION=ضع_هنا_SESSION_الجديد
```

## 🚀 تشغيل البوت

بعد إعداد ملف `.env` بشكل صحيح:
```bash
python main.py
```

أو استخدم زر "▶ Run" في الأعلى

## 📁 هيكل المشروع

```
.
├── main.py                  # ملف التشغيل الأساسي
├── config.py                # إعدادات البوت
├── generate_session.py      # مولد السيشن
├── .env                     # بيانات الاعتماد (لا تشاركها!)
├── FallenMusic/             # كود البوت الرئيسي
│   ├── __init__.py
│   ├── __main__.py
│   ├── Helpers/            # الملفات المساعدة
│   └── Modules/            # موديولات البوت
├── downloads/              # مجلد التحميلات
└── cache/                  # ملفات مؤقتة
```

## ⚠️ ملاحظات هامة

- لا تشارك ملف `.env` أو SESSION مع أحد
- البوت يحتاج صلاحيات Admin في المجموعة لتشغيل الموسيقى
- تأكد من أن الحساب المستخدم في SESSION عضو في نفس المجموعة

## 🆘 حل المشاكل

### خطأ AUTH_KEY_UNREGISTERED
- قم بتشغيل `python generate_session.py` للحصول على session جديد
- حدّث ملف `.env` بالـ SESSION الجديد
- أعد تشغيل البوت

### البوت لا يشتغل
- تأكد من صحة جميع البيانات في `.env`
- تأكد من أن الحساب المستخدم في SESSION ليس محظوراً
- تأكد من اتصال الإنترنت

## 📞 الدعم

- قناة الدعم: https://t.me/+1g787qpaxmU3YWQy
- مجموعة المساعدة: https://t.me/LinkSopranos

---

**تم الإعداد بواسطة Replit Agent** 🤖
