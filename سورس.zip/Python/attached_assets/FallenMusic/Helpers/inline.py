from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

import config
from FallenMusic import BOT_USERNAME

close_key = InlineKeyboardMarkup(
    [[InlineKeyboardButton(text="‹ اغلاق ›", callback_data="close")]]
)


buttons = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton(text="‹ استكمال ›", callback_data="resume_cb"),
            InlineKeyboardButton(text="‹ تخطي ›", callback_data="skip_cb"),
            InlineKeyboardButton(text="‹ ايقاف ›", callback_data="pause_cb"),
        ],
        [
            InlineKeyboardButton(text="‹ انهاء ›", callback_data="end_cb"),
        ]
    ]
)


pm_buttons = [
    [
        InlineKeyboardButton(
            text="‹ أضفني الى مجموعتك ›",
            url=f"https://t.me/{BOT_USERNAME}?startgroup=true",
        )
    ],
    [InlineKeyboardButton(text="‹ الاوامر ›", callback_data="fallen_cb help")],
    [
        InlineKeyboardButton(text="‹ السورس ›", url=config.SUPPORT_CHANNEL),
        InlineKeyboardButton(text="‹ التحديثات ›", url=config.SUPPORT_CHAT),
    ],
    [
        InlineKeyboardButton(
            text="‹ لتنصيب بوت ›", url="https://t.me/"
        ),
        InlineKeyboardButton(text="‹ المطور ›", user_id=config.OWNER_ID),
    ],
]


gp_buttons = [
    [
        InlineKeyboardButton(
            text="‹ أضفني الى مجموعتك ›",
            url=f"https://t.me/{BOT_USERNAME}?startgroup=true",
        )
    ],
    [
        InlineKeyboardButton(text="‹ السورس ›", url=config.SUPPORT_CHANNEL),
        InlineKeyboardButton(text="‹ التحديثات ›", url=config.SUPPORT_CHAT),
    ],
    [
        InlineKeyboardButton(
            text="‹ لتنصيب بوت ›", user_id=config.OWNER_ID
        ),
        InlineKeyboardButton(text="‹ المطور ›", user_id=config.OWNER_ID),
    ],
]


helpmenu = [
    [
        InlineKeyboardButton(
            text="‹ للجميع ›",
            callback_data="fallen_cb help",
        )
    ],
    [
        InlineKeyboardButton(text="‹ الأدمن ›", callback_data="fallen_cb sudo"),
        InlineKeyboardButton(text="‹ المالك ›", callback_data="fallen_cb owner"),
    ],
    [
        InlineKeyboardButton(text="‹ رجوع ›", callback_data="fallen_home"),
        InlineKeyboardButton(text="‹ اغلاق ›", callback_data="close"),
    ],
]


help_back = [
    [InlineKeyboardButton(text="‹ التحديثات ›", url=config.SUPPORT_CHAT)],
    [
        InlineKeyboardButton(text="‹ اغلاق ›", callback_data="close"),
    ],
]
