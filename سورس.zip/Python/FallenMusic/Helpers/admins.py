from typing import Callable
from pyrogram.enums import ChatMemberStatus
from pyrogram.types import CallbackQuery, Message
from FallenMusic import SUDOERS, app

def admin_check(func: Callable) -> Callable:
    async def non_admin(_, message: Message):
        if message.from_user.id in SUDOERS:
            return await func(_, message)

        try:
            member = await app.get_chat_member(message.chat.id, message.from_user.id)
        except:
            return  # يتجاهل بصمت

        if member.status in [ChatMemberStatus.OWNER, ChatMemberStatus.ADMINISTRATOR]:
            return await func(_, message)
        else:
            return  # يتجاهل بصمت

    return non_admin


def admin_check_cb(func: Callable) -> Callable:
    async def cb_non_admin(_, query: CallbackQuery):
        if query.from_user.id in SUDOERS:
            return await func(_, query)

        try:
            member = await app.get_chat_member(query.message.chat.id, query.from_user.id)
        except:
            return  # يتجاهل بصمت

        if member.status in [ChatMemberStatus.OWNER, ChatMemberStatus.ADMINISTRATOR]:
            return await func(_, query)
        else:
            return  # يتجاهل بصمت

    return cb_non_admin
