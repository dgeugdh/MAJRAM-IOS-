import os
import yt_dlp
import urllib.parse

def clean_url(url):
    parsed = urllib.parse.urlparse(url)
    query = urllib.parse.parse_qs(parsed.query)
    video_id = parsed.path.strip('/')

    if "watch" in parsed.path and "v" in query:
        video_id = query["v"][0]
    elif parsed.netloc == "youtu.be":
        video_id = video_id
    else:
        video_id = None

    return f"https://www.youtube.com/watch?v={video_id}" if video_id else url

def audio_dl(url):
    cleaned_url = clean_url(url)

    ydl_opts = {
        'format': 'bestaudio/best',
        'quiet': True,
        'outtmpl': 'downloads/%(title)s.%(ext)s',
        'merge_output_format': 'mp3',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'cookiesfrombrowser': ('firefox', '/home/yusef/snap/firefox/common/.mozilla/firefox/xjdgmtux.default'),
        'extractor_args': {
            'youtubetab': ['skip=authcheck']
        },
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(cleaned_url, download=True)
        return ydl.prepare_filename(info).replace('.webm', '.mp3').replace('.m4a', '.mp3')
