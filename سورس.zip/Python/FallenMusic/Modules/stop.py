from pyrogram import filters
from pyrogram.types import Message

from FallenMusic import app, pytgcalls
from FallenMusic.Helpers import _clear_, admin_check, close_key


@app.on_message(filters.text & filters.group)
@admin_check
async def stop_str(_, message: Message):
    text = message.text.lower()

    if text in ["stop", "end", "توقف", "اسكت", "انهاء"]:  
        try:
            await message.delete()
        except:
            pass
        try:
            await _clear_(message.chat.id)
            await pytgcalls.leave_group_call(message.chat.id)
        except:
            pass

        return await message.reply_text(
            text=f"‹ : **تم ايقاف الاغنية .**\n‹ : بواسطة : {message.from_user.mention} .",
            reply_markup=close_key,
        )
