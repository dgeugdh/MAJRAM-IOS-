import random
from pyrogram import Client, filters
from pyrogram.enums import ChatType, ParseMode, ChatMemberStatus
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    ChatMemberUpdated,
)
from youtubesearchpython.__future__ import VideosSearch

import config
from FallenMusic import BOT_MENTION, BOT_NAME, app
from FallenMusic.Helpers import gp_buttons, pm_buttons
from FallenMusic.Helpers.dossier import *
from FallenMusic.Helpers.inline import helpmenu


@app.on_message(filters.command(["start"]) & ~filters.forwarded)
@app.on_edited_message(filters.command(["start"]) & ~filters.forwarded)
async def fallen_st(_, message: Message):
    if message.chat.type == ChatType.PRIVATE:
        if len(message.text.split()) > 1:
            cmd = message.text.split(None, 1)[1]
            if cmd[0:3] == "inf":
                m = await message.reply_text("🔎")
                query = (str(cmd)).replace("info_", "", 1)
                query = f"https://www.youtube.com/watch?v={query}"
                results = VideosSearch(query, limit=1)
                for result in (await results.next())["result"]:
                    title = result["title"]
                    duration = result["duration"]
                    views = result["viewCount"]["short"]
                    thumbnail = result["thumbnails"][0]["url"].split("?")[0]
                    channellink = result["channel"]["link"]
                    channel = result["channel"]["name"]
                    link = result["link"]
                    published = result["publishedTime"]
                searched_text = f"""
➻ **معلومات المقطع الصوتي 🎶**

📌 **العنوان :** {title}

⏳ **المدة :** {duration} دقيقة  
👁️ **عدد المشاهدات :** `{views}`  
📅 **تاريخ النشر :** {published}  
🔗 **الرابط :** [مشاهدة على يوتيوب]({link})  
📺 **القناة :** [{channel}]({channellink})

💖 تم البحث بواسطة {BOT_NAME}
"""
                key = InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="‹ يوتيوب ›", url=link),
                            InlineKeyboardButton(
                                text="‹ التحديثات ›", url=config.SUPPORT_CHAT
                            ),
                        ],
                    ]
                )
                await m.delete()
                return await app.send_photo(
                    message.chat.id,
                    photo=thumbnail,
                    caption=searched_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=key,
                )
        else:
            await message.reply_photo(
                photo=config.START_IMG,
                caption=PM_START_TEXT.format(
                    message.from_user.first_name,
                    BOT_MENTION,
                ),
                reply_markup=InlineKeyboardMarkup(pm_buttons),
            )
    else:
        await message.reply_photo(
            photo=config.START_IMG,
            caption=START_TEXT.format(
                message.from_user.first_name,
                BOT_MENTION,
                message.chat.title,
                config.SUPPORT_CHAT,
            ),
            reply_markup=InlineKeyboardMarkup(gp_buttons),
        )


bot_replies = [
    "**انت بوت؟ 😳**",
    "**اي سمعتك تصيح بوت، شبيك؟ 🤖**",
    "**لا تصيح بوت ترى أزعل 😤**",
    "**هلا والله بالبــوت 🌚**",
    "**بوت ويش؟ تعال نتحاور 😂**",
    "**عيب تصيحلي بوت، آني حساس ☹️**",
    "**بوت براسك انت 😂**",
    "**خالي آني مو بس بوت، آني روح السيستم 😎**",
    "**تره البوتات عندهم مشاعر همين 🥺**",
    "**لك آني بوت بس محترم، لا تغلط ✋**",
    "**هسه شصار وياك وصحت بوت؟ 🙄**",
    "**شلون عرفت آني بوت؟ جاسوس انت؟ 👀**",
    "**بوت؟ اني بوت وانت شنو؟ 🫣**",
    "**تره اني مجروح من آخر مرة صحتلي بوت 💔**",
]


@app.on_message(filters.text & filters.group)
async def group_text_handler(_, message: Message):
    text = message.text.strip().lower()

    if text in ["الاوامر", "مساعدة", "help"]:
        await message.reply_text(
            "**اختر نوع الأوامر من الأزرار التالية 👇**",
            reply_markup=InlineKeyboardMarkup(helpmenu),
        )
        return

    if text == "بوت":
        reply = random.choice(bot_replies)
        await message.reply_text(reply)


@app.on_chat_member_updated()
async def on_bot_promoted(client, event: ChatMemberUpdated):
    me = await client.get_me()
    if event.new_chat_member.user.id == me.id:
        if event.new_chat_member.status == ChatMemberStatus.ADMINISTRATOR:
            await client.send_message(event.chat.id, "**تم التفعيل تلقائياً**")
