from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message
from youtube_search import YoutubeSearch

from FallenMusic import app


@app.on_message(filters.text & filters.regex(r"^(بحث|search)\s+"))
async def ytsearch(_, message: Message):
    try:
        await message.delete()
    except:
        pass
    try:
        query = message.text.split(None, 1)[1]
    except IndexError:
        return await message.reply_text("‹ : ارسل شي ياحبيبي .")

    m = await message.reply_text("🔎")
    try:
        results = YoutubeSearch(query, max_results=4).to_dict()
        i = 0
        text = ""
        while i < 4:
            text += f"‹ : العنوان : {results[i]['title']}\n"
            text += f"‹ : المدة : `{results[i]['duration']}`\n"
            text += f"‹ : عدد المشاهدات : `{results[i]['views']}`\n"
            text += f"‹ : القناة : {results[i]['channel']}\n"
            text += f"‹ : الرابط : https://youtube.com{results[i]['url_suffix']}\n\n"
            i += 1

        key = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        text="‹ اغلاق ›",
                        callback_data=f"forceclose abc|{message.from_user.id}",
                    ),
                ]
            ]
        )
        await m.edit_text(
            text=text,
            reply_markup=key,
            disable_web_page_preview=True,
        )
    except Exception as e:
        await m.edit_text(f"‹ : صار خطأ أثناء البحث\n\n**{e}**")
