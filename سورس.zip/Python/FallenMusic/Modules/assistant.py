from pyrogram import filters
from pyrogram.types import Message

from FallenMusic import ASS_MENTION, LOGGER, SUDOERS, app, app2


@app.on_message(filters.text & filters.regex("^(asspfp|setpfp|ضيف صورة)$") & SUDOERS) 
async def set_pfp(_, message: Message):
    if message.reply_to_message and message.reply_to_message.photo:
        fuk = await message.reply_text("‹ : جاري تغيير صورة البروفايل للمساعد ...")
        img = await message.reply_to_message.download()
        try:
            await app2.set_profile_photo(photo=img)
            return await fuk.edit_text(f"‹ : تم تغيير صورة {ASS_MENTION} بنجاح.")
        except:
            return await fuk.edit_text("‹ : فشل في تغيير صورة المساعد.")
    else:
        await message.reply_text("‹ : قم بالرد على صورة لتعيينها كصورة للمساعد.")


@app.on_message(filters.text & filters.regex("^(delpfp|delasspfp|مسح صورة)$") & SUDOERS) 
async def del_pfp(_, message: Message):
    try:
        pfp = [p async for p in app2.get_chat_photos("me")]
        await app2.delete_profile_photos(pfp[0].file_id)
        return await message.reply_text("‹ : تم حذف صورة البروفايل للمساعد بنجاح.")
    except Exception as ex:
        LOGGER.error(ex)
        await message.reply_text("‹ : فشل في حذف صورة البروفايل.")


@app.on_message(filters.text & filters.regex("^(assbio|setbio|بايو مساعد)") & SUDOERS) 
async def set_bio(_, message: Message):
    msg = message.reply_to_message
    if msg and msg.text:
        await app2.update_profile(bio=msg.text)
        return await message.reply_text(f"‹ : تم تغيير بايو {ASS_MENTION} بنجاح.")
    elif len(message.text.split()) > 1:
        newbio = message.text.split(None, 1)[1]
        await app2.update_profile(bio=newbio)
        return await message.reply_text(f"‹ : تم تغيير بايو {ASS_MENTION} بنجاح.")
    else:
        return await message.reply_text("‹ : أرسل نصًا أو رد على رسالة لتعيينها كبايو.")


@app.on_message(filters.text & filters.regex("^(assname|setname|تغيير الاسم)") & SUDOERS) 
async def set_name(_, message: Message):
    msg = message.reply_to_message
    if msg and msg.text:
        await app2.update_profile(first_name=msg.text)
        return await message.reply_text(f"‹ : تم تغيير اسم {ASS_MENTION} بنجاح.")
    elif len(message.text.split()) > 1:
        name = message.text.split(None, 1)[1]
        await app2.update_profile(first_name=name, last_name="")
        return await message.reply_text(f"‹ : تم تغيير اسم {ASS_MENTION} بنجاح.")
    else:
        return await message.reply_text("‹ : أرسل نصًا أو رد على رسالة لتعيينها كاسم جديد.")
