from pyrogram import filters
from pyrogram.enums import ChatType
from pyrogram.types import Message

import config
from FallenMusic import BOT_NAME, app


@app.on_message(
    filters.command(["config", "variables"]) & filters.user(config.OWNER_ID)
)
async def get_vars(_, message: Message):
    try:
        await app.send_message(
            chat_id=int(config.OWNER_ID),
            text=f"""<u>**{BOT_NAME} الفارات :**</u>

**ايبي ايدي :** `{config.API_ID}`
**ايبي هاش :** `{config.API_HASH}`

**توكن البوت :** `{config.BOT_TOKEN}`
**اقصى مدة :** `{config.DURATION_LIMIT}`

**ايدي المالك :** `{config.OWNER_ID}`
**يوزرات الادمنية :** `{config.SUDO_USERS}`

**صورة البنك :** `{config.PING_IMG}`
**صورة البدء :** `{config.START_IMG}`
**قناة التحديثات :** `{config.SUPPORT_CHAT}`

**الجلسة :** `{config.SESSION}`""",
            disable_web_page_preview=True,
        )
    except:
        return await message.reply_text("‹ : فشل ارسال الفارات .")
    if message.chat.type != ChatType.PRIVATE:
        await message.reply_text(
            "‹ : تم رسلتهن الك ."
        )
